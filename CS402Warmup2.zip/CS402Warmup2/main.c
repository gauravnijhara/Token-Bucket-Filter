//
//  main.c
//  CS402Warmup2
//
//  Created by Gaurav Nijhara on 2/9/16.
//  Copyright © 2016 Gaurav Nijhara. All rights reserved.
//

#include <stdio.h>
#include "my402list.h"
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>

// check if token bucket can be stack
My402List Q1,Q2,tokenBucket;
pthread_mutex_t Q1Mutex;
pthread_cond_t serverQ;
unsigned int packetCount = 0;
unsigned int bucketSize = 50;

typedef struct packet
{
    int ID;
    int tokensNeeded;
    struct timeval Q1EnterTime,Q2EnterTime,systemTimeOnEnter,systemTimeOnExit,serviceStartTime,serviceEndTime;
    
}packet;

void *packetArrivalMethod(void *args);
void *tokenArrivalMethod(void *args);
void *serverMethod(void *args);
void *server2Method(void *args);

int main(int argc, const char * argv[]) {
    
    pthread_t packetThread,tokenThread,serverThread1,serverThread2;
    pthread_create(&packetThread, NULL,packetArrivalMethod,NULL);
    pthread_create(&tokenThread, NULL,tokenArrivalMethod, NULL);
    pthread_create(&serverThread1, NULL,serverMethod, NULL);
    pthread_create(&serverThread2, NULL,server2Method, NULL);
    
    pthread_join(packetThread, NULL);
    pthread_join(tokenThread, NULL);
    pthread_join(serverThread1, NULL);
    pthread_join(serverThread2, NULL);
    
    
    return 0;
}

void *packetArrivalMethod(void *args)
{
    long long prevTokenArrivalTime=0,currentTime,elapsedTime = 0;
    struct timeval time;
    
    while (1) {
        
        usleep((unsigned int)llabs(5000 - elapsedTime/1000000L));
        
        gettimeofday(&time,NULL);
        currentTime = time.tv_sec + time.tv_usec*1000000L;
        
        packet *newPacket = (packet*)malloc(sizeof(packet));
        
        newPacket->tokensNeeded = ((int)(rand()%20));
        newPacket->ID = ++packetCount;
        
        printf("packet%d arrives , need %d tokens, inter-arrival time = %lld\n",newPacket->ID,newPacket->tokensNeeded,(currentTime-prevTokenArrivalTime));
        
        prevTokenArrivalTime = currentTime;

        newPacket->systemTimeOnEnter = time;
        
        pthread_mutex_lock(&Q1Mutex);
        {
          //  printf("packet enter ");

            
            if (newPacket->tokensNeeded > bucketSize) {
                gettimeofday(&time,NULL);
                elapsedTime = time.tv_sec + time.tv_usec*1000000L - currentTime;
        //        printf("packet exit ");
                pthread_mutex_unlock(&Q1Mutex);
                continue;
            }
            
            
            gettimeofday(&newPacket->Q1EnterTime, NULL);
            printf("packet%d enters Q1",newPacket->ID);
            
            My402ListAppend(&Q1,(void*)newPacket);
            
            packet *dequePacket = (packet*)My402ListFirst(&Q1)->obj;

            
            if (dequePacket->tokensNeeded <= tokenBucket.num_members) {
                
                
                int i = 0;
                while (i < dequePacket->tokensNeeded) {
                    My402ListUnlink(&tokenBucket,My402ListFirst(&tokenBucket));
                    i++;
                }
                
                
                struct timeval temp;
                gettimeofday(&temp, NULL);
                printf("p%d leaves Q1, time in Q1 = %ld, token bucket now has %d token\n",dequePacket->ID,(temp.tv_sec + temp.tv_usec*1000000L) - (dequePacket->Q1EnterTime.tv_sec + dequePacket->Q1EnterTime.tv_usec*1000000L),Q1.num_members);
                
                My402ListUnlink(&Q1, My402ListFirst(&Q1));
                
                gettimeofday(&newPacket->Q2EnterTime, NULL);
                printf("packet%d enters Q2\n",newPacket->ID);
                
                My402ListAppend(&Q2,(packet*)dequePacket);

            }
        }
        
        if (!My402ListEmpty(&Q2)) {
            pthread_cond_broadcast(&serverQ);
        }

      //  printf("packet exit ");

        pthread_mutex_unlock(&Q1Mutex);
        
        
        gettimeofday(&time,NULL);
        elapsedTime = time.tv_sec + time.tv_usec*1000000L - currentTime;

    }
    return(0);
    
}


void *tokenArrivalMethod(void *args)
{
    long long currentTime,elapsedTime=0;
    struct timeval time;

    while (1) {
        
        usleep((unsigned int)llabs(2500 -elapsedTime/1000000L));

        gettimeofday(&time,NULL);
        currentTime = time.tv_sec + time.tv_usec*1000000L;

        pthread_mutex_lock(&Q1Mutex);
        {
         //   printf("token enter ");

            if (tokenBucket.num_members <= 100) {
                int *token = (int*)malloc(sizeof(int));
                My402ListAppend(&tokenBucket,token);
            }
            
            if (Q1.num_members <= 0) {
           //     printf("token exit ");
                pthread_mutex_unlock(&Q1Mutex);
                continue;
            }
            
            packet *dequePacket = (packet*)My402ListFirst(&Q1)->obj;

            if (dequePacket->tokensNeeded <= tokenBucket.num_members) {
                
                
                    int i = 0;
                    while (i < dequePacket->tokensNeeded) {
                        My402ListUnlink(&tokenBucket,My402ListFirst(&tokenBucket));
                        i++;
                    }
                    
                    struct timeval temp;
                    gettimeofday(&temp, NULL);
                    
                    printf("p%d leaves Q1, time in Q1 = %ld, token bucket now has %d token\n",dequePacket->ID,(temp.tv_sec + temp.tv_usec*1000000L) - (dequePacket->Q1EnterTime.tv_sec + dequePacket->Q1EnterTime.tv_usec*1000000L),Q1.num_members);
                    
                    My402ListUnlink(&Q1, My402ListFirst(&Q1));

                    printf("packet%d enters Q2\n",dequePacket->ID);
                
                    My402ListAppend(&Q2,(packet*)dequePacket);
                }
                
                if (!My402ListEmpty(&Q2)) {
                    pthread_cond_broadcast(&serverQ);
                }
            
         //   printf("token exit ");
            pthread_mutex_unlock(&Q1Mutex);
        }
        
        gettimeofday(&time,NULL);
        elapsedTime = time.tv_sec + time.tv_usec*1000000L - currentTime;

    }
    return(0);
}

void *serverMethod(void *args)
{
    long long currentTime = 0,elapsedTime;

    while (1) {
        
        pthread_mutex_lock(&Q1Mutex);
        

        while (My402ListEmpty(&Q2)) {
            pthread_cond_wait(&serverQ, &Q1Mutex);
        }
        
       // printf("server enter ");

        packet *dequePacket = (packet*)My402ListFirst(&Q2)->obj;
        struct timeval temp;
        gettimeofday(&temp, NULL);
        
        My402ListUnlink(&Q2,My402ListFirst(&Q2));

        printf("p%d leaves Q2, time in Q2 = %ld\n",dequePacket->ID,(temp.tv_sec + temp.tv_usec*1000000L) - (dequePacket->Q2EnterTime.tv_sec + dequePacket->Q2EnterTime.tv_usec*1000000L));
        
       // printf("server exit ");

        pthread_mutex_unlock(&Q1Mutex);
        
        gettimeofday(&dequePacket->serviceStartTime,NULL);
        elapsedTime = dequePacket->serviceStartTime.tv_sec + dequePacket->serviceStartTime.tv_usec*1000000L - currentTime;

        printf("p%d begins service at S%d, requesting %dms of service\n",dequePacket->ID,1,100);
     
        usleep((unsigned int)llabs(28571-elapsedTime/1000000L));

        gettimeofday(&dequePacket->serviceEndTime,NULL);
        currentTime = dequePacket->serviceEndTime.tv_sec + dequePacket->serviceEndTime.tv_usec*1000000L;

        printf("p% departs from S1, service time = %lldms , time in system = %ldms\n",dequePacket->ID,(currentTime - (dequePacket->serviceStartTime.tv_sec + dequePacket->serviceStartTime.tv_usec*1000)),(dequePacket->serviceStartTime.tv_sec + dequePacket->serviceStartTime.tv_usec*1000000L) - (dequePacket->serviceEndTime.tv_sec + dequePacket->serviceEndTime.tv_usec*1000000L));
       
    }
    return(0);
}

void *server2Method(void *args)
{
    long long currentTime = 0,elapsedTime;
    
    while (1) {
        
        pthread_mutex_lock(&Q1Mutex);
        
        
        while (My402ListEmpty(&Q2)) {
            pthread_cond_wait(&serverQ, &Q1Mutex);
        }
        
        //printf("server2 enter ");
        
        packet *dequePacket = (packet*)My402ListFirst(&Q2)->obj;
        struct timeval temp;
        gettimeofday(&temp, NULL);
        
        My402ListUnlink(&Q2,My402ListFirst(&Q2));
        
         printf("p%d leaves Q2, time in Q2 = %ld\n",dequePacket->ID,(temp.tv_sec + temp.tv_usec*1000000L) - (dequePacket->Q2EnterTime.tv_sec + dequePacket->Q2EnterTime.tv_usec*1000000L));
        
        //printf("server2 exit ");
        
        pthread_mutex_unlock(&Q1Mutex);
        
        gettimeofday(&dequePacket->serviceStartTime,NULL);
        elapsedTime = dequePacket->serviceStartTime.tv_sec + dequePacket->serviceStartTime.tv_usec*1000000L - currentTime;
        
          printf("p%d begins service at S%d, requesting %dms of service\n",dequePacket->ID,1,100);
        
        usleep((unsigned int)llabs(28571-elapsedTime/1000000L));
        
        gettimeofday(&dequePacket->serviceEndTime,NULL);
        currentTime = dequePacket->serviceEndTime.tv_sec + dequePacket->serviceEndTime.tv_usec*1000000L;
        
           printf("p% departs from S1, service time = %lldms , time in system = %ldms\n",dequePacket->ID,(currentTime - (dequePacket->serviceStartTime.tv_sec + dequePacket->serviceStartTime.tv_usec*1000)),(dequePacket->serviceStartTime.tv_sec + dequePacket->serviceStartTime.tv_usec*1000000L) - (dequePacket->serviceEndTime.tv_sec + dequePacket->serviceEndTime.tv_usec*1000000L));
        
    }
    return(0);
}


